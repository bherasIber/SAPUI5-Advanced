sap.ui.define(["sap/ui/core/mvc/Controller"],function(n){"use strict";return n.extend("logaligroup.rrhh.HTML5Module.controller.App",{onInit:function(){}})});
//# sourceMappingURL=App.controller.js.map